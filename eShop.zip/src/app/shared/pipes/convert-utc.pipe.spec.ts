import { ConvertUTCPipe } from './convert-utc.pipe';

describe('ConvertUTCPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertUTCPipe();
    expect(pipe).toBeTruthy();
  });
});
